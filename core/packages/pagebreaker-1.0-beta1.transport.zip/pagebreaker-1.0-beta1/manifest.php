<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2627628d0341e235d0a4dfbe0ede3f16',
      'native_key' => 'pagebreaker',
      'filename' => 'modNamespace/2756251e7943225cc8e53bf0e93207e0.vehicle',
      'namespace' => 'pagebreaker',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'bb3b6dd55050f49d50c8df8644ef9d27',
      'native_key' => 13,
      'filename' => 'modPlugin/4fae3f49d520355afd6a914a7610093f.vehicle',
      'namespace' => 'pagebreaker',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'd0dc34b40c7be9c0c30c72714d371eba',
      'native_key' => 14,
      'filename' => 'modPlugin/c4fe28414e5d75ad321c27b7a2be31e0.vehicle',
      'namespace' => 'pagebreaker',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '361e2a43410d4172ee5d79cca44e09fc',
      'native_key' => 1,
      'filename' => 'modCategory/908663d321db64d3f178885d8e2c5bc4.vehicle',
      'namespace' => 'pagebreaker',
    ),
  ),
);