--------------------
Snippet: getPage
--------------------
Version: 1.1.0-pl
Since: March 19, 2010
Author: Jason Coward <jason@modxcms.com>

A generic wrapper snippet for returning paged results and navigation from snippets that return limitable collections. This release requires MODX Revolution 2.1+.

Official Documentation:
http://rtfm.modx.com/display/ADDON/getPage