--------------------
Snippet: Archivist
--------------------
Created: June 3rd, 2010
Author: Shaun McCormick <shaun@modx.com>
License: GNU GPLv2 (or later at your option)

This is a simple archiving component. Please see the documentation at:
http://rtfm.modx.com/display/ADDON/Archivist/

Thanks for using Archivist!
Shaun McCormick
shaun@modx.com