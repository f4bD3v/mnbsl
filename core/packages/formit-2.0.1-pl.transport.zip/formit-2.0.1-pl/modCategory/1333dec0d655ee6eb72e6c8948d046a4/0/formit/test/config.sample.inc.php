<?php
$config['modx_base_path'] = '/www/path/to/modx/';