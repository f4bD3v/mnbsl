MODx Revolution Frontpage editor plugin

Packaged for MODx Revolution 
S. Hamblett steve.hamblett@linux.com Nov 2010
Updated : May 2011

This package contains a plugin that allows front end editing in
MODx Revolution. It implements a cross between the MODx Evolution
QM and PubKit packages now with a choice of the classic submit 
option or the AJAXified Aloha editor

Please refer to the User Guide in /assets/components/frontpage/docs
for usage of this product.
