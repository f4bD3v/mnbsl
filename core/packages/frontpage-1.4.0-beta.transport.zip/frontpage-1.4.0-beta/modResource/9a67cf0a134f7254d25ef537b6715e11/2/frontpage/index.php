<?php
/**
 *  * Base controller file
 *
 * @category  Provisioning
 * @author    S. Hamblett <steve.hamblett@linux.com>
 * @copyright 2009 S. Hamblett
 * @license   GPLv3 http://www.gnu.org/licenses/gpl.html
 * @link      none
 * 
 * @package provisioner
 */

return include dirname(__FILE__).'/controllers/index.php';
